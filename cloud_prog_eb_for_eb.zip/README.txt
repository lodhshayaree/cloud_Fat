Elastic Beanstalk deployment package (generated)

How to use:
1. Upload the ZIP to Elastic Beanstalk (Python platform).
2. EB will install dependencies from requirements.txt and run the Procfile:
   web: gunicorn application:app
3. The Flask app serves the HTML files placed under /templates.
4. Default root served: templates/application.html

Notes:
- If you want different behavior (e.g., single-page app or static assets),
  move files into the "static" folder and update routes in application.py.
