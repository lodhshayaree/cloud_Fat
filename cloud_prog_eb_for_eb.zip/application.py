from flask import Flask, send_from_directory, render_template, abort
import os

app = Flask(__name__, static_folder="static", template_folder="templates")

@app.route("/")
def index():
    # change default page here if you prefer another file
    return render_template("application.html")

@app.route("/<path:filename>")
def serve_file(filename):
    # try templates first (HTML pages), otherwise static folder
    tpl_path = os.path.join(app.template_folder, filename)
    static_path = os.path.join(app.static_folder, filename)
    if os.path.exists(tpl_path):
        return render_template(filename)
    elif os.path.exists(static_path):
        return send_from_directory(app.static_folder, filename)
    else:
        abort(404)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)))
